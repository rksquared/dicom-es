import * as es from './es';

console.log('Deleting index...');

es.deleteIndex();